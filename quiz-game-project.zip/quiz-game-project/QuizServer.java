import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class QuizServer {
    private static final int PORT = 1234; // 서버 포트 번호
    private static final Map<String, List<String>> periodicTableQuestions = new LinkedHashMap<>();
    private static final Map<String, List<String>> chemicalFormulaQuestions = new LinkedHashMap<>();
    private static final long QUIZ_DURATION = 1; // 퀴즈 제한 시간 (1분)

    static {
        // 주기율표 문제 (한국어와 영어 답변 포함)
        periodicTableQuestions.put("H는 어떤 원소인가요?", Arrays.asList("수소", "hydrogen"));
        periodicTableQuestions.put("O는 어떤 원소인가요?", Arrays.asList("산소", "oxygen"));
        periodicTableQuestions.put("C는 어떤 원소인가요?", Arrays.asList("탄소", "carbon"));
        periodicTableQuestions.put("N는 어떤 원소인가요?", Arrays.asList("질소", "nitrogen"));
        periodicTableQuestions.put("Fe는 어떤 원소인가요?", Arrays.asList("철", "iron"));
        periodicTableQuestions.put("Na는 어떤 원소인가요?", Arrays.asList("나트륨", "소듐", "sodium"));

        // 화학식 문제 (한국어와 영어 답변 포함)
        chemicalFormulaQuestions.put("H₂O는 무엇인가요?", Arrays.asList("물", "수", "water"));
        chemicalFormulaQuestions.put("NaCl은 무엇인가요?", Arrays.asList("소금", "염화나트륨", "salt", "sodium chloride"));
        chemicalFormulaQuestions.put("CO₂는 무엇인가요?", Arrays.asList("이산화탄소", "탄산가스", "carbon dioxide"));
        chemicalFormulaQuestions.put("CH₄는 무엇인가요?", Arrays.asList("메테인", "메탄", "methane"));
    }

    // 총점 계산 (주기율표 문제: 최대 1.5점, 화학식 문제: 최대 2점)
    private static final double MAX_SCORE = (periodicTableQuestions.size() * 1.5) + (chemicalFormulaQuestions.size() * 2);

    public static void main(String[] args) {
        System.out.println("Quiz server started on port " + PORT);
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept(); // 클라이언트 연결 수락
                System.out.println("Client connected.");
                new QuizHandler(clientSocket).start(); // 새 스레드에서 클라이언트 요청 처리
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class QuizHandler extends Thread {
        private Socket clientSocket;
        private double score = 0;
        private boolean isTimeUp = false; // 시간 초과 플래그
        private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        QuizHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            // 퀴즈 제한 시간 설정 (1분)
            scheduler.schedule(() -> {
                isTimeUp = true;
                System.out.println("Time's up! Ending quiz for client.");
            }, QUIZ_DURATION, TimeUnit.MINUTES);

            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
            ) {
                out.println("QUIZ_START (You have 1 minute)"); // 퀴즈 시작 메시지 전송

                // 주기율표 문제 처리
                for (String question : periodicTableQuestions.keySet()) {
                    if (isTimeUp) break; // 시간 초과 시 종료
                    out.println("QUESTION:" + question); // 질문 전송
                    String answer = in.readLine().trim();

                    List<String> correctAnswers = periodicTableQuestions.get(question);
                    boolean isCorrect = false;
                    boolean isEnglish = false;

                    // 답변 검증 (한국어와 영어 답변 구분)
                    for (String correctAnswer : correctAnswers) {
                        if (answer.equalsIgnoreCase(correctAnswer)) {
                            isCorrect = true;
                            if (correctAnswer.matches("[a-zA-Z ]+")) {
                                isEnglish = true;
                            }
                            break;
                        }
                    }

                    // 점수 계산 및 피드백 전송
                    if (isCorrect) {
                        if (isEnglish) {
                            score += 1.5;
                            out.println("Correct! (+1.5 points)");
                        } else {
                            score += 1.0;
                            out.println("Correct! (+1 point)");
                        }
                    } else {
                        out.println("Incorrect! 정답은: " + correctAnswers.get(0));
                    }
                }

                // 화학식 문제 처리
                for (String question : chemicalFormulaQuestions.keySet()) {
                    if (isTimeUp) break; // 시간 초과 시 종료
                    out.println("QUESTION:" + question); // 질문 전송
                    String answer = in.readLine().trim();

                    List<String> correctAnswers = chemicalFormulaQuestions.get(question);
                    boolean isCorrect = false;
                    boolean isEnglish = false;

                    // 답변 검증 (한국어와 영어 답변 구분)
                    for (String correctAnswer : correctAnswers) {
                        if (answer.equalsIgnoreCase(correctAnswer)) {
                            isCorrect = true;
                            if (correctAnswer.matches("[a-zA-Z ]+")) {
                                isEnglish = true;
                            }
                            break;
                        }
                    }

                    // 점수 계산 및 피드백 전송
                    if (isCorrect) {
                        if (isEnglish) {
                            score += 2.0;
                            out.println("Correct! (+2 points)");
                        } else {
                            score += 1.5;
                            out.println("Correct! (+1.5 points)");
                        }
                    } else {
                        out.println("Incorrect! 정답은: " + correctAnswers.get(0));
                    }
                }

                // 퀴즈 종료 메시지 전송
                if (isTimeUp) {
                    out.println("TIME UP! Quiz ended. Final score: " + score + "/" + MAX_SCORE);
                } else {
                    out.println("QUIZ_END. Your final score is: " + score + "/" + MAX_SCORE);
                }
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                scheduler.shutdown();
            }
        }
    }
}
