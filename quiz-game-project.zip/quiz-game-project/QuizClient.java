import java.io.*;
import java.net.*;
import java.util.Properties;

public class QuizClient {
    private static String SERVER_IP = "127.0.0.1"; // 기본 IP 주소
    private static int SERVER_PORT = 1234;         // 기본 포트 번호

    public static void main(String[] args) {
        loadServerInfo(); // 서버 정보 로드

        try (
            Socket socket = new Socket(SERVER_IP, SERVER_PORT); // 서버와 소켓 연결
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // 서버로부터 메시지 읽기
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true); // 서버로 메시지 전송
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in)) // 사용자 입력 받기
        ) {
            String serverMessage;

            // 서버 메시지 처리 루프
            while ((serverMessage = in.readLine()) != null) {
                if (serverMessage.equals("QUIZ_START")) {
                    // 퀴즈 시작 메시지
                    System.out.println("퀴즈가 시작됩니다! \n 영어 및 한국어로 답변해 주세요! 영어로 답변하면 보너스 점수가 있답니다!");
                } else if (serverMessage.startsWith("QUESTION:")) {
                    // 질문 출력 및 사용자 입력 처리
                    System.out.println(serverMessage.substring(9)); // 질문 내용 출력
                    System.out.print("답변: ");
                    String answer = userInput.readLine(); // 사용자 입력
                    out.println(answer); // 입력값 서버로 전송
                } else if (serverMessage.equals("QUIZ_END") || serverMessage.startsWith("TIME UP")) {
                    // 퀴즈 종료 또는 시간 초과 메시지 처리
                    System.out.println(serverMessage);
                    break;
                } else {
                    // 기타 메시지 (정답 여부 또는 점수 출력)
                    System.out.println(serverMessage);
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // 입출력 예외 처리
        }
    }

    private static void loadServerInfo() {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream("server_info.dat")) {
            // server_info.dat 파일에서 서버 IP 및 포트 정보 로드
            properties.load(fis);
            SERVER_IP = properties.getProperty("IP_ADDRESS", "127.0.0.1"); // IP 주소 설정
            SERVER_PORT = Integer.parseInt(properties.getProperty("PORT", "1234")); // 포트 번호 설정
        } catch (IOException e) {
            // 파일을 읽지 못한 경우 기본값 사용
            System.out.println("Could not load server info, using default values.");
        }
    }
}
