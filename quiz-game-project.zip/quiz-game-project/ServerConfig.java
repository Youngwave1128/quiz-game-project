import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ServerConfig {
    private String serverIp = "127.0.0.1"; // 기본 IP 주소
    private int serverPort = 1234;         // 기본 포트 번호

    public ServerConfig(String configFilePath) {
        if (!loadConfig(configFilePath)) {
            System.out.println("Config file not found. Creating default config file.");
            saveDefaultConfig(configFilePath);
        }
    }

    private boolean loadConfig(String configFilePath) {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(configFilePath)) {
            properties.load(fis);
            serverIp = properties.getProperty("IP_ADDRESS", serverIp);
            serverPort = Integer.parseInt(properties.getProperty("PORT", String.valueOf(serverPort)));
            return true; // 파일을 성공적으로 로드한 경우 true 반환
        } catch (IOException e) {
            return false; // 파일 로드 실패 시 false 반환
        }
    }

    private void saveDefaultConfig(String configFilePath) {
        Properties properties = new Properties();
        properties.setProperty("IP_ADDRESS", serverIp);
        properties.setProperty("PORT", String.valueOf(serverPort));
        try (FileOutputStream fos = new FileOutputStream(configFilePath)) {
            properties.store(fos, "Default server configuration");
            System.out.println("Default config file created: " + configFilePath);
        } catch (IOException e) {
            System.out.println("Failed to create config file.");
        }
    }

    public String getServerIp() {
        return serverIp;
    }

    public int getServerPort() {
        return serverPort;
    }

    // 테스트용 main 메서드 추가
    public static void main(String[] args) {
        ServerConfig config = new ServerConfig("server_info.dat");
        System.out.println("Server IP: " + config.getServerIp());
        System.out.println("Server Port: " + config.getServerPort());
    }
}
